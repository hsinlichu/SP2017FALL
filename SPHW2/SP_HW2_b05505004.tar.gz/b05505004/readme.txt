1.Execution

run the bidding_system and pass two arguments as below,
./bidding_system  [host_num]  [player_num]

2.Description
I use select() in bidding system to make the assignment more efficient. In bidding system, i use assign function to calculate all combination of each four player, and assign to host sequently.
In the bonus, i pay half money which i have, except the last time i pay all.To ensure i can use the less money win each round.  

3.Self-Examination
I complete all of the subtasks. I only open specific number of host which required, and use select() to ensure the assignment is efficient. Furthemore, I have test all of combination of my bidding_system, host, player and sample's in workstation.
